<?php
/**
 * Created by PhpStorm.
 * User: phuongth
 * Date: 1/22/2016
 * Time: 5:06 PM
 */
?>
<h2>Product search template</h2>
